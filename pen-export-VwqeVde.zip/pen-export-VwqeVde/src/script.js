function filterByName(e) {
  const items = document.querySelectorAll("#list li");
  const searchTerm = e.target.value.trim().toLowerCase();
  
  items.forEach(item => {
    item.style.display = 'revert';
    
    if (!item.innerText.toLowerCase().includes(searchTerm)) {
      item.style.display = 'none';
    }
  })
}